﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BankEntity;
using BankException;
using BankOperations;

namespace BankValidations
{
    public class ValidationBank
    {
        public static bool ValidBankObj(Bank b)
        {
            bool bankValidated = true;
            try
            {
                StringBuilder sb = new StringBuilder();
                if (b.CustomerName == null || b.CustomerName == String.Empty)
                {
                    bankValidated = false;
                    sb.Append("Customer Name Cannot be Empty");
                }
                if (b.AccountBal < 500)
                {
                    bankValidated = false;
                    sb.Append("Minimum Balance of 500 must be maintained");
                }
                if(b.AccountType!=Bank.AccountTypeEnum.Current && b.AccountType != Bank.AccountTypeEnum.Saving)
                {
                    bankValidated = false;
                    sb.Append("Bank AccountType can be only Saving or Current");
                }
                if(b.AccountType != Bank.AccountTypeEnum.Current || b.AccountType != Bank.AccountTypeEnum.Saving)
                {
                    if (b.AccountType == Bank.AccountTypeEnum.Current)
                        if ((b.CurrentAccountNumber).ToString().Length != 6)
                        {
                            bankValidated = false;
                            sb.Append("Bank CurrentAccountNumber Length must be exactly 6");
                        }
                    else if (b.AccountType == Bank.AccountTypeEnum.Saving)
                        if ((b.SavingAccountNumber).ToString().Length != 6)
                        {
                            bankValidated = false;
                            sb.Append("Bank SavingsAccountNumber Length must be exactly 6");
                        }
                }
                if (!bankValidated)
                {
                    throw new BankExceeptionClass(sb.ToString());
                }
            }
            catch (BankExceeptionClass ex) { throw ex; }
            catch (SystemException ex) { throw ex; }

            return bankValidated;
        }

        public static bool AddCustomer(Bank b)
        {
            bool custAdded = false;
            try
            {
                if(ValidBankObj(b))
                {
                    custAdded = BankDAL.AddCustomer(b);
                }
            }
            catch (BankExceeptionClass ex) { throw ex; }
            catch (SystemException ex) { throw ex; }
            return custAdded;
        }

        public static Bank CheckBalance(int Accno, Bank.AccountTypeEnum AccType)
        {
            Bank b = null;
            try
            {
                b = BankDAL.CheckBalance(Accno, AccType);
            }
            catch (BankExceeptionClass ex) { throw ex; }
            catch (SystemException ex) { throw ex; }
            return b;
        }

        public static Bank Withdraw(int Accno, Bank.AccountTypeEnum AccType, double Amt)
        {
            Bank b = null;
            try
            {
                b = BankDAL.Withdraw(Accno,AccType,Amt);
            }
            catch (BankExceeptionClass ex) { throw ex; }
            catch (SystemException ex) { throw ex; }

            return b;
        }

        public static Bank Deposit(int Accno, Bank.AccountTypeEnum AccType, double Amt)
        {
            Bank b = null;
            try
            {
                b = BankDAL.Deposit(Accno,AccType,Amt);
            }
            catch (BankExceeptionClass ex) { throw ex; }
            catch (SystemException ex) { throw ex; }

            return b;
        }

        public static List<Bank> Retrieve()
        {
            List<Bank> bankList = null;
            try
            {
                bankList = BankDAL.Retrieve();
            }
            catch (BankExceeptionClass ex) { throw ex; }
            catch (SystemException ex) { throw ex; }

            return bankList;
        }
    }
}
